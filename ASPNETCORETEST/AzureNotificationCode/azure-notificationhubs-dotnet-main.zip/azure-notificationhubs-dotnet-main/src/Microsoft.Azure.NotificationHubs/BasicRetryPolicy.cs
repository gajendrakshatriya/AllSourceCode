﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.NotificationHubs.Messaging;

namespace Microsoft.Azure.NotificationHubs
{
    /// <summary>
    ///   The default retry policy for the Service Bus client library, respecting the
    ///   configuration specified as a set of <see cref="NotificationHubRetryOptions" />.
    /// </summary>
    ///
    /// <seealso cref="NotificationHubRetryOptions"/>
    ///
    internal class BasicRetryPolicy : NotificationHubRetryPolicy
    {
        /// <summary>The seed to use for initializing random number generated for a given thread-specific instance.</summary>
        private static int s_randomSeed = Environment.TickCount;

        /// <summary>The random number generator to use for a specific thread.</summary>
        private static readonly ThreadLocal<Random> RandomNumberGenerator = new ThreadLocal<Random>(() => new Random(Interlocked.Increment(ref s_randomSeed)), false);

        /// <summary>
        ///   The set of options responsible for configuring the retry
        ///   behavior.
        /// </summary>
        ///
        public NotificationHubRetryOptions Options { get; }

        /// <summary>
        ///   The factor to apply to the base delay for use as a base jitter value.
        /// </summary>
        ///
        /// <value>This factor is used as the basis for random jitter to apply to the calculated retry duration. 
        /// It defines the magnitude of a random offset for retry backoff intervals, to amortize request spikes from this client.</value>
        ///
        public double JitterFactor { get; } = 0.08;

        /// <summary>
        ///   Initializes a new instance of the <see cref="BasicRetryPolicy"/> class.
        /// </summary>
        ///
        /// <param name="retryOptions">The options which control the retry approach.</param>
        ///
        public BasicRetryPolicy(NotificationHubRetryOptions retryOptions)
        {
            Options = retryOptions ?? throw new ArgumentNullException(nameof(retryOptions));
        }

        /// <summary>
        ///   Calculates the amount of time to wait before another attempt should be made.
        /// </summary>
        ///
        /// <param name="lastException">The last exception that was observed for the operation to be retried.</param>
        /// <param name="attemptCount">The number of total attempts that have been made, including the initial attempt before any retries.</param>
        ///
        /// <returns>The amount of time to delay before retrying the associated operation; if <c>null</c>, then the operation is no longer eligible to be retried.</returns>
        ///
        public override TimeSpan? CalculateRetryDelay(
            Exception lastException,
            int attemptCount)
        {
            if (Options.MaxRetries <= 0
                || Options.Delay == TimeSpan.Zero
                || Options.MaxDelay == TimeSpan.Zero
                || attemptCount > Options.MaxRetries
                || !ShouldRetryException(lastException))
            {
                return null;
            }

            var baseJitterSeconds = Options.Delay.TotalSeconds * JitterFactor;

            TimeSpan retryDelay;

            if (lastException is MessagingException messagingException && messagingException.RetryAfter.HasValue)
            {
                retryDelay = messagingException.RetryAfter.Value;
            }
            else
            {
                switch (Options.Mode)
                {
                    case NotificationHubRetryMode.Fixed:
                        retryDelay = CalculateFixedDelay(Options.Delay.TotalSeconds, baseJitterSeconds, RandomNumberGenerator.Value);
                        break;
                    case NotificationHubRetryMode.Exponential:
                        retryDelay = CalculateExponentialDelay(attemptCount, Options.Delay.TotalSeconds, baseJitterSeconds, RandomNumberGenerator.Value);
                        break;
                    default:
                        throw new NotSupportedException($"Unsupported retry mode {Options.Mode}");
                };
            }

            // Adjust the delay, if needed, to keep within the maximum
            // duration.

            if (Options.MaxDelay < retryDelay)
            {
                return Options.MaxDelay;
            }

            return retryDelay;
        }

        /// <summary>
        ///   Determines if an exception should be retried.
        /// </summary>
        ///
        /// <param name="exception">The exception to consider.</param>
        ///
        /// <returns><c>true</c> to retry the exception; otherwise, <c>false</c>.</returns>
        ///
        private static bool ShouldRetryException(Exception exception)
        {
            if (exception is TaskCanceledException || exception is OperationCanceledException)
            {
                exception = exception?.InnerException;
            }
            else if (exception is AggregateException aggregateEx)
            {
                exception = aggregateEx?.Flatten().InnerException;
            }

            switch (exception)
            {
                case null:
                    return false;

                case MessagingException ex:
                    return ex.IsTransient;

                case TimeoutException _:
                case SocketException _:
                    return true;

                default:
                    return false;
            }
        }

        /// <summary>
        ///   Calculates the delay for an exponential back-off.
        /// </summary>
        ///
        /// <param name="attemptCount">The number of total attempts that have been made, including the initial attempt before any retries.</param>
        /// <param name="baseDelaySeconds">The delay to use as a basis for the exponential back-off, in seconds.</param>
        /// <param name="baseJitterSeconds">The delay to use as the basis for a random jitter value, in seconds.</param>
        /// <param name="random">The random number generator to use for the calculation.</param>
        ///
        /// <returns>The recommended duration to delay before retrying; this value does not take the maximum delay or eligibility for retry into account.</returns>
        ///
        private static TimeSpan CalculateExponentialDelay(
            int attemptCount,
            double baseDelaySeconds,
            double baseJitterSeconds,
            Random random) =>
            TimeSpan.FromSeconds(Math.Pow(2, attemptCount) * baseDelaySeconds + random.NextDouble() * baseJitterSeconds);

        /// <summary>
        ///   Calculates the delay for a fixed back-off.
        /// </summary>
        ///
        /// <param name="baseDelaySeconds">The delay to use as a basis for the fixed back-off, in seconds.</param>
        /// <param name="baseJitterSeconds">The delay to use as the basis for a random jitter value, in seconds.</param>
        /// <param name="random">The random number generator to use for the calculation.</param>
        ///
        /// <returns>The recommended duration to delay before retrying; this value does not take the maximum delay or eligibility for retry into account.</returns>
        ///
        private static TimeSpan CalculateFixedDelay(
            double baseDelaySeconds,
            double baseJitterSeconds,
            Random random) =>
            TimeSpan.FromSeconds(baseDelaySeconds + random.NextDouble() * baseJitterSeconds);
    }
}
